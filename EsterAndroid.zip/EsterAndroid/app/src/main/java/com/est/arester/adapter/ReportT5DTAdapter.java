package com.est.arester.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.est.arester.R;
import com.est.arester.model.laporantop5driver.LaporanTop5Driver;

import java.util.List;

public class ReportT5DTAdapter extends RecyclerView.Adapter<ReportT5DTAdapter.MyViewHolder> {
    private List<LaporanTop5Driver> laporanTop5DriverModelList;
    private Context context;

    public ReportT5DTAdapter(List<LaporanTop5Driver> laporanTop5DriverModels) {
        this.laporanTop5DriverModelList = laporanTop5DriverModels;
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView txtNamaDriver, txtIdDriver, txtJumlahTransaksi;
        public MyViewHolder(View itemView) {
            super(itemView);
            txtNamaDriver = (TextView) itemView.findViewById(R.id.txtNamaDriver);
            txtIdDriver = (TextView) itemView.findViewById(R.id.txtIdDriver);
            txtJumlahTransaksi = (TextView) itemView.findViewById(R.id.txtJumlahTransaksi);

        }
    }

    @Override
    public ReportT5DTAdapter.MyViewHolder onCreateViewHolder (ViewGroup parent, int viewType){
        View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_laporan3, parent, false);
        ReportT5DTAdapter.MyViewHolder mViewHolder = new ReportT5DTAdapter.MyViewHolder(mView);
        return mViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ReportT5DTAdapter.MyViewHolder holder, int position) {
        final LaporanTop5Driver laporanTop5Driver = laporanTop5DriverModelList.get(position);
        holder.txtNamaDriver.setText(laporanTop5Driver.getNamaDriver());
        holder.txtIdDriver.setText(laporanTop5Driver.getIdDriver());
        holder.txtJumlahTransaksi.setText(laporanTop5Driver.getJumlahTransaksi());
    }

    @Override
    public int getItemCount() {
        return laporanTop5DriverModelList.size();
    }
}
