@extends('dashboard.dashboard')
@section('content')

    <div class="container-fluid py-4" style="padding-left : 0%">
        <div class="row">
            <div class="col-10">
                <div class="card my-4">

                    <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                        <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                            <h6 class="text-black mx-3 text-center">
                                <strong> DATA TRANSAKSI UAJY RENTAL</strong> 
                            </h6>
                        </div>
                    </div>

                            <div>
                                <a class="fa fa-user-plus" href="{{ route('transaksi.create') }}">Tambah Transaksi</a>
                            </div>

                            <form action="{{ route('transaksi.index') }}" method="GET">
                                <div class="mb-3 col-md-6 position-relative mt-n4 mx-3 z-index-2">
                                    <div class="input-group input-group-outline">
                                        <label class="form-label">Cari Disini</label>
                                            <input type="search" class="form-control" name="search">
                                    </div>
                                </div>
                            </form>

                            {{-- <form action="{{ route('data-mitra.index') }}" method="GET" class="float-end">
                                <div class="input-group mb-3">
                                    <span class="input-group-text bg-white" id="basic-addon1">
                                        <i class="fa-solid fa-magnifying-glass"></i>
                                    </span>
                                    <input type="search" name="search" class="form-control" placeholder="cari.." aria-label="search" aria-describedby="basic-addon1">
                                </div>
                            </form> --}}


                                    
                    <div class="card-body px-0 pb-2 position-relative mt-n4 mx-3 z-index-2">
                        <table class="table table-bordered">
                            <tr>
                                <th class="text-center">Id Transaksi</th>
                                <th class="text-center">Status Transaksi</th>
                                <th class="text-center">Action</th>
                            </tr>
            
                    @if(count($transaksi))
                    @foreach($transaksi as $trn)
            
                            <tr>
                                <td class="text-center">{{ $trn->id }}</td>
{{--                                 @if (count($role))
                                    @foreach ($role as $data)
                                        @if($pgw->id_role == $data->id)
                                        <td class="text-center">{{ $data->nama_role }}</td>
                                    @endif
                                    @endforeach
                                    @endif --}}
                                <td class="text-center">{{ $trn->status_transaksi }}</td>
                                <td class="text-center">
                                    <form action="{{ route('transaksi.destroy', $trn->id) }}" method="POST">
                                        <a class="btn fa fa-eye" href="{{ route('transaksi.show',$trn->id) }}"><i class="material-icons" style="font-size: 20px">Show</i></a>
                                        <a class="btn fa fa-edit" href="{{ route('transaksi.edit',$trn->id) }}"><i class="material-icons" style="font-size: 20px">Edit</i></a>
                                        
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn fa fa-trash-o" onclick="return confirm('Apakah Anda Yakin Ingin Menghapus Data Ini?'"><i class="material-icons" style="font-size: 20px">Delete</i></button>
                                    </form>
                                </td>
                            </tr>
                            @endforeach
                            @else
                            <tr>
                                <td align="center" clospan="3">-</td>
                            </tr>
                            @endif    
                        </table>
                    </div>
                </div>                                           
@endsection