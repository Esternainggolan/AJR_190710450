<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Mobil extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();

    }
    // function tampilriwayatbyid_get() {
    //     $id_customer = $this->post('id_customer');
    //     $riwayattransaksi = $this->db->get('transaksi')->result();
    //     $this->response(array("riwayattransaksi"=>$riwayattransaksi, 200));
    // }
    function tampillaporanpenyewaanmobilperbulan_get() {
        $laporanbulanan = $this->db->query("SELECT d.tipe_mobil as tipe_mobil, d.nama_mobil as nama_mobil, count(t.id_aset) as jumlah_peminjaman, sum(t.total_biaya_sewa) as pendapatan from transaksi t join aset_kendaraan d on t.id_aset = d.id group by t.id_aset")->result();
        $this->response(array("laporanpenyewaanmobilbulanan"=>$laporanbulanan, 200));
    }
    function carilaporanpenyewaanmobilperbulan_post() {
        $bulan = $this->post('bulan');
        $laporanbulanan = $this->db->query("SELECT d.tipe_mobil as tipe_mobil, d.nama_mobil as nama_mobil, count(t.id_aset) as jumlah_peminjaman, sum(t.total_biaya_sewa) as pendapatan from transaksi t join aset_kendaraan d on t.id_aset = d.id where month(t.tanggal_transaksi) in ('".$bulan."') group by t.id_aset order by pendapatan desc")->result();
        $this->response(array("laporanpenyewaanmobilbulanan"=>$laporanbulanan, 200));
    }

    
}

?>