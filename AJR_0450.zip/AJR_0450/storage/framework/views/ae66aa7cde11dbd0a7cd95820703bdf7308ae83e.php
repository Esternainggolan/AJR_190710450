
<?php $__env->startSection('content'); ?>

    <div class="container-fluid py-4" style="padding-left : 0%">
        <div class="row">
            <div class="col-10">
                <div class="card my-4">

                    <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                        <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                            <h6 class="text-black mx-3 text-center">
                                <strong> DATA TRANSAKSI UAJY RENTAL</strong> 
                            </h6>
                        </div>
                    </div>

                            <div>
                                <a class="fa fa-user-plus" href="<?php echo e(route('transaksi.create')); ?>">Tambah Transaksi</a>
                            </div>

                            <form action="<?php echo e(route('transaksi.index')); ?>" method="GET">
                                <div class="mb-3 col-md-6 position-relative mt-n4 mx-3 z-index-2">
                                    <div class="input-group input-group-outline">
                                        <label class="form-label">Cari Disini</label>
                                            <input type="search" class="form-control" name="search">
                                    </div>
                                </div>
                            </form>

                            


                                    
                    <div class="card-body px-0 pb-2 position-relative mt-n4 mx-3 z-index-2">
                        <table class="table table-bordered">
                            <tr>
                                <th class="text-center">Id Transaksi</th>
                                <th class="text-center">Status Transaksi</th>
                                <th class="text-center">Action</th>
                            </tr>
            
                    <?php if(count($transaksi)): ?>
                    <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                            <tr>
                                <td class="text-center"><?php echo e($trn->id); ?></td>

                                <td class="text-center"><?php echo e($trn->status_transaksi); ?></td>
                                <td class="text-center">
                                    <form action="<?php echo e(route('transaksi.destroy', $trn->id)); ?>" method="POST">
                                        <a class="btn fa fa-eye" href="<?php echo e(route('transaksi.show',$trn->id)); ?>"><i class="material-icons" style="font-size: 20px">Show</i></a>
                                        <a class="btn fa fa-edit" href="<?php echo e(route('transaksi.edit',$trn->id)); ?>"><i class="material-icons" style="font-size: 20px">Edit</i></a>
                                        
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn fa fa-trash-o" onclick="return confirm('Apakah Anda Yakin Ingin Menghapus Data Ini?'"><i class="material-icons" style="font-size: 20px">Delete</i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>
                                <td align="center" clospan="3">-</td>
                            </tr>
                            <?php endif; ?>    
                        </table>
                    </div>
                </div>                                           
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AJR_0450\resources\views/TransaksiCRUD/index.blade.php ENDPATH**/ ?>