

<?php $__env->startSection('content'); ?>
   
<div class="d-flex justify-content-between mt-5 mb-5">
    <div>
        <h2>Pegawai CRUD</h2>
    </div>
    <div>
        <a class="btn btn-success" href="<?php echo e(route('pegawai.create')); ?>">Tambah Data Pegawai</a>
    </div>
</div>

    <table class="table table-bordered">
        <tr>
            <th class="text-center">Id</th>
            <th class="text-center">Role</th>
            <th class="text-center">Nama Pegawai</th>
            <th class="text-center">Action</th>
        </tr>

        <?php if(count($pegawai)): ?>
        <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pgw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td class="text-center"><?php echo e($pgw->id); ?></td>
            <td class="text-center"><?php echo e($pgw->id_role); ?></td>
            <td><?php echo e($pgw->nama_pegawai); ?></td>
            <td class="text-center">
                <form action="<?php echo e(route('pegawai.destroy', $pgw->id)); ?>" method="POST">
                    <a class="btn btn-info btn-sm" href="<?php echo e(route('pegawai.show',$pgw->id)); ?>">Show</a>
                    <a class="btn btn-primary btn-sm" href="<?php echo e(route('pegawai.edit',$pgw->id)); ?>">Edit</a>
                    
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda Yakin Ingin Menghapus Data Ini?'">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <tr>
            <td align="center" clospan="3">Empty Data!!</td>
        </tr>
    <?php endif; ?>    
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xamp\htdocs\AJR_0450\resources\views/PegawaiCRUD/index.blade.php ENDPATH**/ ?>