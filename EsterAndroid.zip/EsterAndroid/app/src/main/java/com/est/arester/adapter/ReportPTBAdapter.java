package com.est.arester.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.est.arester.R;
import com.est.arester.model.laporanpendapatanbulanan.LaporanPendapatanBulan;

import java.util.List;

public class ReportPTBAdapter extends RecyclerView.Adapter<ReportPTBAdapter.MyViewHolder> {
    private List<LaporanPendapatanBulan> laporanPendapatanBulans;
    private Context context;

    public ReportPTBAdapter(List<LaporanPendapatanBulan> laporanPendapatanBulanList) {
        this.laporanPendapatanBulans = laporanPendapatanBulanList;
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView txtNamaCustomer, txtNamaMobil, txtJumlahTransaksi, txtPendapatan, txtJenisTransaksi;
        public MyViewHolder(View itemView) {
            super(itemView);
            txtPendapatan = (TextView) itemView.findViewById(R.id.txtPendapatan);
            txtJumlahTransaksi = (TextView) itemView.findViewById(R.id.txtJumlahTransaksi);
            txtNamaCustomer = (TextView) itemView.findViewById(R.id.txtNamaCustomer);
            txtNamaMobil = (TextView) itemView.findViewById(R.id.txtNamaMobil);
            txtJenisTransaksi = (TextView) itemView.findViewById(R.id.txtJenisTransaksi);

        }
    }

    @Override
    public ReportPTBAdapter.MyViewHolder onCreateViewHolder (ViewGroup parent, int viewType){
        View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_laporan2, parent, false);
        ReportPTBAdapter.MyViewHolder mViewHolder = new ReportPTBAdapter.MyViewHolder(mView);
        return mViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ReportPTBAdapter.MyViewHolder holder, int position) {
        final LaporanPendapatanBulan laporanPendapatanBulan = laporanPendapatanBulans.get(position);
        holder.txtNamaMobil.setText(laporanPendapatanBulan.getNamaMobil());
        holder.txtJumlahTransaksi.setText(laporanPendapatanBulan.getJumlahTransaksi());
        holder.txtPendapatan.setText("Rp "+laporanPendapatanBulan.getPendapatan());
        if(laporanPendapatanBulan.getJenisTrx().equals("Peminjaman Mobil")){
            holder.txtJenisTransaksi.setText("Peminjaman Mobil");
        }else{
            holder.txtJenisTransaksi.setText("Peminjaman Mobil + Driver");
        }

    }

    @Override
    public int getItemCount() {
        return laporanPendapatanBulans.size();
    }
}
