

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between mt-5 mb-5">
    <div>
        <h2>Edit Data Kendaraan</h2>
    </div>
    <div>
        <a class="btn btn-secondary" href="<?php echo e(route('kendaraan.index')); ?>">Back</a>
    </div>
</div>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($errors); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<div class="container-fluid">
    
    <div class="card mb-3">
        <form action="<?php echo e(route('kendaraan.update', $aset_kendaraan->id)); ?>" method="POST" enctype="multipart/form-data">
            <div class="row g-0">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="col-md-8">
                    <div class="card-body">
                        <div class="col-md col-sm">
                            <label class="mb-2">Nama Mobil</label>
                            <input type="text" class="form-control mb-3" value="<?php echo e($aset_kendaraan->nama_mobil); ?>" name="nama_mobil">
                        </div>
    
                        <div class="col-md col-sm">
                            <label class="mb-2">Tipe Mobil</label>
                        <input type="text" class="form-control mb-3" value="<?php echo e($aset_kendaraan->tipe_mobil); ?>" name="tipe_mobil">
                        </div>

                        <div class="col-md col-sm">
                            <label class="mb-2">Jenis Transmisi</label>
                            <input type="text" class="form-control mb-3" value="<?php echo e($aset_kendaraan->jenis_transmisi); ?>" name="jenis_transmisi">
                        </div>

                        <div class="col-md col-sm">
                            <label class="mb-2">Jenis Bahan Bakar</label>
                            <input type="text" class="form-control mb-3" value="<?php echo e($aset_kendaraan->jenis_bahan_bakar); ?>" name="jenis_bahan_bakar">
                        </div>

                        <div class="col-md col-sm">
                            <label class="mb-2">Volume Bahan Bakar</label>
                            <input type="text" class="form-control mb-3" value="<?php echo e($aset_kendaraan->volume_bahan_bakar); ?>" name="volume_bahan_bakar">
                        </div> 

                        <div class="col-md col-sm">
                            <label class="mb-2">Warna Mobil</label>
                            <input type="text" class="form-control mb-3" value="<?php echo e($aset_kendaraan->warna_mobil); ?>" name="warna_mobil">
                        </div>
                        
                        <div class="col-md col-sm">
                            <label class="mb-2">Kapasitas Mobil</label>
                        <input type="text" class="form-control mb-3" value="<?php echo e($aset_kendaraan->kapasitas_mobil); ?>" name="kapasitas_mobil">
                        </div>

                        <div class="col-md col-sm">
                            <label class="mb-2">Fasilitas Mobil</label>
                        <input type="text" class="form-control mb-3" value="<?php echo e($aset_kendaraan->fasilitas_mobil); ?>" name="fasilitas_mobil">
                        </div>

                        <div class="col-md col-sm">
                            <label class="mb-2">Plat Nomor</label>
                        <input type="text" class="form-control mb-3" value="<?php echo e($aset_kendaraan->plat_nomor); ?>" name="plat_nomor">
                        </div>

                        <div class="col-md col-sm">
                            <label class="mb-2">Nomor STNK</label>
                        <input type="text" class="form-control mb-3" value="<?php echo e($aset_kendaraan->no_stnk); ?>" name="no_stnk">
                        </div>

                        <div class="col-md col-sm">
                            <label class="mb-2">Kategori Aset</label>
                        <input type="text" class="form-control mb-3" value="<?php echo e($aset_kendaraan->kategori_aset); ?>" name="kategori_aset">
                        </div>

                        <div class="col-md col-sm">
                            <label class="mb-2">Terakhir Service</label>
                        <input type="date" class="form-control mb-3" value="<?php echo e($aset_kendaraan->tgl_service_terakhir); ?>" name="tgl_service_terakhir">
                        </div>

                        <div class="col-md col-sm">
                            <label class="mb-2">Status Ketersediaan Mobil</label>
                        <input type="text" class="form-control mb-3" value="<?php echo e($aset_kendaraan->status_ketersediaan_mobil); ?>" name="status_ketersediaan_mobil">
                        </div>

                        <div class="col-md col-sm">
                            <label class="mb-2">Biaya Sewa</label>
                        <input type="text" class="form-control mb-3" value="<?php echo e($aset_kendaraan->biaya_sewa); ?>" name="biaya_sewa">
                        </div>
 
                    </div>
                </div>
                <div class="d-flex justify-content-center">
                    <button class="btn btn-outline-primary mx-2" type="submit">Ubah</button>
                    <button class="btn btn-outline-danger mx-2" type="reset">Batal</button>
                </div>
            </div>
        </form>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xamp\htdocs\AJR_0450\resources\views/KendaraanCRUD/edit.blade.php ENDPATH**/ ?>