<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Login extends REST_Controller {

    //0=tidak aktif
    //1=sudah dikonfirmasi admin
    //2=masih belum dikonfirmasi
    //3=konfirmasi dibatalkan



    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();
       
    }


    public function Login_post(){
            $nama_user = $this->post('nama_user');
            $password_user = $this->post('password_user');
            //$jabatan_user = $this->post('jabatan_user');
            $status_user = 1;
            $status_cabang = 1;
           	$query = $this->db->select('users.id_user, users.jabatan_user, cabang.id_cabang, cabang.nama_cabang')
                ->from('users')
                ->join('cabang', 'cabang.id_cabang = users.id_cabang', 'LEFT')
                ->where('users.status_user', $status_user)
                ->where('users.nama_user', $nama_user)
                ->where('users.password_user', md5($password_user))
                ->where('cabang.status', $status_cabang)
                ->get()->result();
        //     $query = $this->db->query("SELECT id_user FROM `".$this->db->dbprefix('users')."` WHERE id_cabang='".$id_cabang."' AND nama_user='".$nama_user."' AND 
        //     password_user='".md5($password_user)."' AND jabatan_user='".$jabatan_user."' AND status_user = '".$status_user."'");
        //    if ($query->num_rows() > 0 )
            if($query)
            {  
                $this->response(array("result"=>$query,'status' => 'Sukses login'), 200);
            }else{
                $this->response(array('status' => 'Gagal login'), 502);
            }
    }

}


?>