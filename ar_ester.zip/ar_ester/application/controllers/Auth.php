<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Auth extends REST_Controller {

    //0=tidak aktif
    //1=sudah dikonfirmasi admin
    //2=masih belum dikonfirmasi
    //3=konfirmasi dibatalkan



    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();
        $this->load->model('UsersModel');
        $this->model = $this->UsersModel;
    }

    public function login_post(){
        $email = $this->post('email');
        $password = $this->post('password');
        $query = $this->db->select('*')
            ->from('customer')
            ->where('password_customer',$password)
            ->where('email_customer', $email)
            ->get()->result();
        if (count($query) > 0 )
        {  
            $this->response(array("result"=>$query,'status' => 'Sukses login', 'role' => 'customer'), 200);
        }else{
            $query = $this->db->select('*')
            ->from('driver')
            ->where('password_driver',$password)
            ->where('email_driver', $email)
            ->get()->result();
            if (count($query) > 0 )
            {  
                $this->response(array("result"=>$query,'status' => 'Sukses login', 'role' => 'driver'), 200);
            }else{
                $query = $this->db->select('*')
                ->from('pegawai')
                ->where('password_pegawai',$password)
                ->where('email_pegawai', $email)
                ->get()->result();
                if (count($query) > 0 )
                {  
                    $this->response(array("result"=>$query,'status' => 'Sukses login', 'role' => 'pegawai'), 200);
                }else{
                    $this->response(array('status' => 'Gagal login'), 502);
                }
            }
        }
    }


}


?>