<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Customer extends REST_Controller {



    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();

    }
    // function tampilriwayatbyid_get() {
    //     $id_customer = $this->post('id_customer');
    //     $riwayattransaksi = $this->db->get('transaksi')->result();
    //     $this->response(array("riwayattransaksi"=>$riwayattransaksi, 200));
    // }
    
    function tampillaporantop5customer_get() {
        $laporantop5customer = $this->db->query("SELECT d.id as id_customer, d.nama_lengkap, count(t.id) as jumlah_transaksi from customer d join transaksi t on d.id = t.id_customer group by d.id order by jumlah_transaksi desc limit 5")->result();
        $this->response(array("laporantop5customer"=>$laporantop5customer, 200));
    }
    function carilaporantop5customer_post() {
        $bulan = $this->post('bulan');
        $laporantop5customer = $this->db->query("SELECT d.id as id_customer, d.nama_lengkap, count(t.id) as jumlah_transaksi from customer d join transaksi t on d.id = t.id_customer where month(t.tanggal_transaksi) in ('".$bulan."') group by d.id order by jumlah_transaksi desc limit 5")->result();
        $this->response(array("laporantop5customer"=>$laporantop5customer, 200));
    }
    function tampilriwayatbyid_post() {
        $id_customer = $this->post('id_customer');
        $riwayattransaksi = $this->db->select('*')
        ->from('transaksi')
        ->where('id_customer', $id_customer)
        ->get()->result();
        $this->response(array("riwayattransaksi"=>$riwayattransaksi, 200));
    }

    function tampilpromo_post() {
        $status_promo = $this->post('status_promo');
        $promo = $this->db->select('*')
        ->from('promo')
        ->where('status_promo', $status_promo)
        ->get()->result();
        $this->response(array("promo"=>$promo, 200));
    }

    function searchpromo_post() {
        $status_promo = $this->post('status_promo');
        $kode_promo = $this->post('kode_promo');
        $promo = $this->db->select('*')
        ->from('promo')
        ->where('status_promo', $status_promo)
        ->where('kode_promo', $kode_promo)
        ->get()->result();
        $this->response(array("promo"=>$promo, 200));
    }
   
    function tampilbrosur_post() {
        $status_ketersedian_mobil = $this->post('status_ketersediaan_mobil');
        $asetkendaraan = $this->db->select('*')
        ->from('aset_kendaraan')
        ->where('status_ketersediaan_mobil', $status_ketersedian_mobil)
        ->get()->result();
        $this->response(array("asetkendaraan"=>$asetkendaraan, 200));
    }

}

?>