<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PegawaiController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\PromoController;
use App\Http\Controllers\DriverController;
use App\Http\Controllers\KendaraanController;
use App\Http\Controllers\MitraController;
use App\Http\Controllers\ScheduleController;
use App\Http\Controllers\TransaksiController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('dashboard', function() {
    return view('dashboard.dashboard');
});

Route::resource('pegawai', PegawaiController::class);
Route::resource('customer', CustomerController::class);
Route::resource('promo', PromoController::class);
Route::resource('driver', DriverController::class);
Route::resource('kendaraan', KendaraanController::class);
Route::resource('mitra', MitraController::class);
Route::resource('schedule', ScheduleController::class);
Route::resource('transaksi', TransaksiController::class);

// Route::get('/searchpegawai', [PegawaiController::class, 'search'])-> name('searchpegawai');
// Route::get('/searchpromo', [PromoController::class, 'search'])-> name('searchpromo');
// Route::get('/searchmitra', [MitraController::class, 'search'])-> name('searchmitra');
// Route::get('/searchcustomer', [CustomerController::class, 'search'])-> name('searchcustomer');
// Route::get('/searchaset', [KendaraanController::class, 'search'])-> name('searchaset');
// Route::get('/searchjadwal', [JadwalController::class, 'search'])-> name('searchjadwal');
// Route::get('/searchdriver', [DriverController::class, 'search'])-> name('searchdriver');
// Route::get('/searchtransaksi', [TransaksiController::class, 'search'])-> name('searchtransaksi');