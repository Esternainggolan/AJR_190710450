

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between mt-10 mb-10">
    <div class="text-center">
        <h2>Show Data Customer</h2>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div class="d-flex justify-content-center">
            <div class="card card-primary card-outline">
                <div class="card-body box-profile"> 
                    <hr>
                        <strong>
                            <i class="fa-solid fa-id-badge"></i>
                            Id Customer
                        </strong>
                        <p class="text-muted"><?php echo e($customer->id); ?></p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-id-badge"></i>
                            Nama Customer
                        </strong>
                        <p class="text-muted"><?php echo e($customer->nama_lengkap); ?></p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-id-badge"></i>
                            Tanggal Lahir
                        </strong>
                        <p class="text-muted"><?php echo e($customer->tgl_lahir_customer); ?></p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-id-badge"></i>
                            Jenis Kelamin
                        </strong>
                        <p class="text-muted"><?php echo e($customer->jenis_kelamin_customer); ?></p>
                        <hr>

                        <strong>
                            <i class="bi bi-arrow-up-left-circle-fill"></i>
                            Alamat Customer
                        </strong>
                        <p class="text-muted"><?php echo e($customer->alamat_customer); ?></p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-genderless"></i>
                            Nomor Telepon
                        </strong>
                        <p class="text-muted"><?php echo e($customer->no_telp_customer); ?></p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-genderless"></i>
                            Email
                        </strong>
                        <p class="text-muted"><?php echo e($customer->email_customer); ?></p>
                        <hr>

                </div>
                        <div class="text-center">
                            <a class="btn btn-secondary" href="<?php echo e(route('customer.index')); ?>">Back</a>
                        </div>

            </div>

        </div>

    </div>

</div>
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xamp\htdocs\AJR_0450\resources\views/CustomerCRUD/show.blade.php ENDPATH**/ ?>