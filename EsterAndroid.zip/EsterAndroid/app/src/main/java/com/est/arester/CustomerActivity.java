package com.est.arester;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.est.arester.adapter.KatalogAdapter;
import com.est.arester.adapter.PromoAdapter;
import com.est.arester.adapter.RTCAdapter;
import com.est.arester.model.brosur.AsetKendaraan;
import com.est.arester.model.brosur.BrosurModel;
import com.est.arester.model.promo.Promo;
import com.est.arester.model.promo.PromoModel;
import com.est.arester.model.riwayattransaksi;
import com.est.arester.model.riwayattransaksimodel;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CustomerActivity extends AppCompatActivity {

    EditText edtSearchPromo;
    TextView txtLogout, btnCariPromo,btnCekRatingDriver;
    private RTCAdapter mAdapter;
    private PromoAdapter promoAdapter;
    private KatalogAdapter katalogAdapter;
    private RecyclerView pRecyclerView;
    private RecyclerView.LayoutManager pLayoutManager;
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private RecyclerView bRecyclerView;
    private RecyclerView.LayoutManager bLayoutManager;
    SharedPreferences sharedPreferences;
    private static final String SHARED_PREF_NAME = "mypref";
    private static final String KEY_ID = "id";
    String id = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnCariPromo = findViewById(R.id.btnCariPromo);
        edtSearchPromo = findViewById(R.id.edtSearchPromo);
        mRecyclerView = findViewById(R.id.rvRiwayatTransaksiCustomer);
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        pRecyclerView = findViewById(R.id.rvPromo);
        pLayoutManager = new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false);
        pRecyclerView.setLayoutManager(pLayoutManager);
        btnCekRatingDriver = findViewById(R.id.btnCekRatingDriver);
        bRecyclerView = findViewById(R.id.rvBrosur);
        bLayoutManager = new GridLayoutManager(this, 2);
        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME,MODE_PRIVATE);
        id = sharedPreferences.getString(KEY_ID,null);
        bRecyclerView.setLayoutManager(bLayoutManager);
        txtLogout = findViewById(R.id.txtLogout);
        txtLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CustomerActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        btnCekRatingDriver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CustomerActivity.this, TampilPerfomaDriverActivity.class);
                startActivity(intent);
            }
        });
        btnCariPromo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtSearchPromo.getText().toString().equals("")){
                    getPromo();
                }else{
                    searchPromo(edtSearchPromo.getText().toString());
                }

            }
        });
        getPromo();
        getRiwayatTrxCustomer();
        getBrosur();
    }

    private void getBrosur() {
        Interface anInterface = Network.getClient().create(Interface.class);
        Call<BrosurModel> brosurCall = anInterface.getbrosur("Tersedia");
        brosurCall.enqueue(new Callback<BrosurModel>() {
            @Override
            public void onResponse(Call<BrosurModel> call, Response<BrosurModel> response) {

                if(response.isSuccessful()){
                    List<AsetKendaraan> asetKendaraans = response.body().getAsetkendaraan();
                    katalogAdapter = new KatalogAdapter(asetKendaraans);
                    bRecyclerView.setAdapter(katalogAdapter);
                }else{
                    Toast.makeText(getApplicationContext(), "Gagal "+response.message().toString(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<BrosurModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Gagal", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void searchPromo(String kode) {
        Interface anInterface = Network.getClient().create(Interface.class);
        Call<PromoModel> promoCall = anInterface.getpromosearch("Tersedia", kode);
        promoCall.enqueue(new Callback<PromoModel>() {
            @Override
            public void onResponse(Call<PromoModel> call, Response<PromoModel> response) {
                List<Promo> promos = response.body().getPromo();
                promoAdapter = new PromoAdapter(promos);
                pRecyclerView.setAdapter(promoAdapter);
            }

            @Override
            public void onFailure(Call<PromoModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Gagal", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getPromo() {
        Interface anInterface = Network.getClient().create(Interface.class);
        Call<PromoModel> promoCall = anInterface.getpromo("Tersedia");
        promoCall.enqueue(new Callback<PromoModel>() {
            @Override
            public void onResponse(Call<PromoModel> call, Response<PromoModel> response) {
                List<Promo> promos = response.body().getPromo();
                promoAdapter = new PromoAdapter(promos);
                pRecyclerView.setAdapter(promoAdapter);
            }

            @Override
            public void onFailure(Call<PromoModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Gagal", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getRiwayatTrxCustomer() {
        Interface anInterface = Network.getClient().create(Interface.class);
        Call<riwayattransaksimodel> riwayattransaksimodelCall = anInterface.getriwayatcustomer(id);
        riwayattransaksimodelCall.enqueue(new Callback<riwayattransaksimodel>() {
            @Override
            public void onResponse(Call<riwayattransaksimodel> call, Response<riwayattransaksimodel> response) {
                List<riwayattransaksi> riwayattransaksis = response.body().getRiwayattransaksi();
                mAdapter = new RTCAdapter(riwayattransaksis);
                mRecyclerView.setAdapter(mAdapter);
            }

            @Override
            public void onFailure(Call<riwayattransaksimodel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Gagal", Toast.LENGTH_SHORT).show();
            }
        });
    }
}