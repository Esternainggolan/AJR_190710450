

<?php $__env->startSection('content'); ?>
   
<div class="container-fluid py-4" style="padding-left : 0%">
        <div class="row">
            <div class="col-10">
                <div class="card my-4">

                    <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                        <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                            <h6 class="text-black mx-3 text-center">
                                <strong> DATA PEGAWAI UAJY RENTAL</strong> 
                            </h6>
                        </div>
                    </div>

                    <div>
                        <a class="fa fa-user-plus" href="<?php echo e(route('pegawai.create')); ?>">Tambah Pegawai</a>
                    </div>

                    <form action="<?php echo e(route('pegawai.index')); ?>" method="GET">
                        <div class="mb-3 col-md-6 position-relative mt-n4 mx-3 z-index-2">
                            <div class="input-group input-group-outline">
                                <label class="form-label">Cari Data</label>
                                    <input type="search" class="form-control" name="search">
                            </div>
                        </div>
                    </form>

    <table class="table table-bordered">
        <tr>
            <th class="text-center">Id</th>
            <th class="text-center">Role</th>
            <th class="text-center">Nama Pegawai</th>
            <th class="text-center">Action</th>
        </tr>

        <?php if(count($pegawai)): ?>
        <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pgw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td class="text-center"><?php echo e($pgw->id); ?></td>
            <td class="text-center"><?php echo e($pgw->id_role); ?></td>
            <td><?php echo e($pgw->nama_pegawai); ?></td>
            <td class="text-center">
                <form action="<?php echo e(route('pegawai.destroy', $pgw->id)); ?>" method="POST">
                    <a class="btn fa fa-eye" href="<?php echo e(route('pegawai.show',$pgw->id)); ?>">Show</a>
                    <a class="btn fa fa-edit" href="<?php echo e(route('pegawai.edit',$pgw->id)); ?>">Edit</a>
                    
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn fa fa-check" onclick="return confirm('Apakah Anda Yakin Ingin Menghapus Data Ini?'">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <tr>
            <td align="center" clospan="3">-</td>
        </tr>
    <?php endif; ?>    
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AJR_0450\resources\views/PegawaiCRUD/index.blade.php ENDPATH**/ ?>