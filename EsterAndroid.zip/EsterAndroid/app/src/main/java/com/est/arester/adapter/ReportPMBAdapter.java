package com.est.arester.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.est.arester.R;
import com.est.arester.model.laporanmobilbulanan.Laporanpenyewaanmobilbulanan;

import java.util.List;

public class ReportPMBAdapter extends RecyclerView.Adapter<ReportPMBAdapter.MyViewHolder> {
    private List<Laporanpenyewaanmobilbulanan> laporanpenyewaanmobilbulananList;
    private Context context;

    public ReportPMBAdapter(List<Laporanpenyewaanmobilbulanan> laporanpenyewaanmobilbulanans) {
        this.laporanpenyewaanmobilbulananList = laporanpenyewaanmobilbulanans;
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView txtTipeMobil, txtNamaMobil, txtJumlahPeminjaman, txtPendapatan;
        public MyViewHolder(View itemView) {
            super(itemView);
            txtPendapatan = (TextView) itemView.findViewById(R.id.txtPendapatan);
            txtJumlahPeminjaman = (TextView) itemView.findViewById(R.id.txtJumlahPeminjaman);
            txtTipeMobil = (TextView) itemView.findViewById(R.id.txtTipeMobil);
            txtNamaMobil = (TextView) itemView.findViewById(R.id.txtNamaMobil);

        }
    }

    @Override
    public ReportPMBAdapter.MyViewHolder onCreateViewHolder (ViewGroup parent, int viewType){
        View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_laporan1, parent, false);
        ReportPMBAdapter.MyViewHolder mViewHolder = new ReportPMBAdapter.MyViewHolder(mView);
        return mViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ReportPMBAdapter.MyViewHolder holder, int position) {
        final Laporanpenyewaanmobilbulanan laporanpenyewaanmobilbulanan = laporanpenyewaanmobilbulananList.get(position);
        holder.txtNamaMobil.setText(laporanpenyewaanmobilbulanan.getNamaMobil());
        holder.txtJumlahPeminjaman.setText(laporanpenyewaanmobilbulanan.getJumlahPeminjaman());
        holder.txtPendapatan.setText("Rp "+laporanpenyewaanmobilbulanan.getPendapatan());
        holder.txtTipeMobil.setText(laporanpenyewaanmobilbulanan.getNamaMobil());
    }

    @Override
    public int getItemCount() {
        return laporanpenyewaanmobilbulananList.size();
    }
}
