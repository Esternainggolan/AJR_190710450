

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between mt-5 mb-5">
    <div>
        <h2>Tambah Data Pegawai</h2>
    </div>
    <div>
        <a class="btn btn-secondary" href="<?php echo e(route('pegawai.index')); ?>">Back</a>
    </div>
</div>

<?php if($errors->any()): ?>
    <div class="alert alert-danger" >
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($errors); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="container-fluid">
    <h1 class="fs-3">Tambah Data Pegawai</h2>

        <form action="<?php echo e(route('pegawai.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group row my-3">
                <label for="colFormLabel" class="col-sm-2 col-form-label">Nama Lengkap</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="colFormLabel" name="nama_pegawai" required>
                </div>
            </div>

            <div class="form-group row my-3">
                <label for="colFormLabel" class="col-sm-2 col-form-label">Alamat</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="colFormLabel" name="alamat_pegawai">
                </div>
            </div>

            <div class="form-group row my-3">
                <label for="colFormLabel" class="col-sm-2 col-form-label">Tanggal Lahir</label>
                <div class="col-sm-10">
                    <input type="date" class="form-control" id="colFormLabel" name="tgl_lahir_pegawai">
                </div>
            </div>

            <div class="form-group row my-3">
                <label for="colFormLabel" class="col-sm-2 col-form-label">Jenis Kelamin</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="colFormLabel" name="jenis_kelamin_pegawai">
                </div>
            </div>

            <div class="form-group row my-3">
                <label for="colFormLabel" class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                    <input type="email" class="form-control" id="colFormLabel" name="email_pegawai">
                </div>
            </div>

            <div class="form-group row my-3">
                <label for="colFormLabel" class="col-sm-2 col-form-label">Nomor Telepon</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="colFormLabel" name="no_telp_pegawai">
                </div>
            </div>

            <div class="form-group row my-3">
                <label for="colFormLabel" class="col-sm-2 col-form-label">Id Role</label>
                <div class="col-sm-10">
                    <input type="number" class="form-control" id="colFormLabel" name="id_role">
                </div>
            </div>
            
            <div class="form-group row my-3">
                <label for="formFile" class="col-sm-2 col-form-label">Foto</label>
                <div class="col-sm-10">
                    <input class="form-control" type="file" id="formFile" name="foto_pegawai">
                </div>
            </div>            

            <div class="d-flex justify-content-center">
                <button class="btn btn-outline-primary mx-2" type="submit">Tambah</button>
                <button class="btn btn-outline-danger mx-2" type="reset">Batal</button>
            </div>
            
        </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xamp\htdocs\AJR_0450\resources\views/PegawaiCRUD/create.blade.php ENDPATH**/ ?>