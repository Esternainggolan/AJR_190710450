@extends('dashboard.dashboard')

@section('content')

<div class="d-flex justify-content-between mt-10 mb-10">
    <div class="text-center">
        <h2>Show Data Driver</h2>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div class="d-flex justify-content-center">
            <div class="card card-primary card-outline">
                <div class="card-body box-profile"> 
                    <hr>
                        <strong>
                            <i class="fa-solid fa-id-badge"></i>
                            Id Driver
                        </strong>
                        <p class="text-muted">{{ $driver->id}}</p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-id-badge"></i>
                            Nama Driver
                        </strong>
                        <p class="text-muted">{{ $driver->nama_driver}}</p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-id-badge"></i>
                            Tanggal Lahir
                        </strong>
                        <p class="text-muted">{{ $driver->tgl_lahir_driver}}</p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-id-badge"></i>
                            Jenis Kelamin
                        </strong>
                        <p class="text-muted">{{ $driver->jenis_kelamin_driver}}</p>
                        <hr>

                        <strong>
                            <i class="bi bi-arrow-up-left-circle-fill"></i>
                            Alamat Customer
                        </strong>
                        <p class="text-muted">{{ $driver->alamat_driver}}</p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-genderless"></i>
                            Nomor Telepon
                        </strong>
                        <p class="text-muted">{{ $driver->no_telp_driver}}</p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-genderless"></i>
                            Email
                        </strong>
                        <p class="text-muted">{{ $driver->email_driver}}</p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-genderless"></i>
                            Status
                        </strong>
                        <p class="text-muted">{{ $driver->status_tersedia_driver}}</p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-genderless"></i>
                            Bahasa
                        </strong>
                        <p class="text-muted">{{ $driver->bahasa}}</p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-genderless"></i>
                            File Pdf
                        </strong>
                        <p class="text-muted">{{ $driver->file_pdf}}</p>
                        <hr>
                       
                </div>
                <div class="text-center">
                            <a class="btn fa fa-close" href="{{ route('driver.index') }}">Back</a>
                        </div>  

            </div>

        </div>

    </div>

</div>
       
@endsection