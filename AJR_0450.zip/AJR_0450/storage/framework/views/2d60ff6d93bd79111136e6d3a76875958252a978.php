

<?php $__env->startSection('content'); ?>
   
<div class="container-fluid py-4" style="padding-left : 0%">
        <div class="row">
            <div class="col-10">
                <div class="card my-4">

                    <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                        <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                            <h6 class="text-black mx-3 text-center">
                                <strong> DATA DRIVER UAJY RENTAL</strong> 
                            </h6>
                        </div>
                    </div>

                            <div>
                                <a class="fa fa-user-plus" href="<?php echo e(route('driver.create')); ?>">Tambah Driver</a>
                            </div>

                            <form action="<?php echo e(route('driver.index')); ?>" method="GET">
                                <div class="mb-3 col-md-6 position-relative mt-n4 mx-3 z-index-2">
                                    <div class="input-group input-group-outline">
                                        <label class="form-label">Cari Disini</label>
                                            <input type="search" class="form-control" name="search">
                                    </div>
                                </div>
                            </form>

    <table class="table table-bordered">
        <tr>
            <th class="text-center">Id</th>
            <th class="text-center">Nama Driver</th>
            <th class="text-center">Status driver</th>
            <th class="text-center">Action</th>
        </tr>

        <?php if(count($driver)): ?>
        <?php $__currentLoopData = $driver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td class="text-center"><?php echo e($drv->id); ?></td>
            <td><?php echo e($drv->nama_driver); ?></td>
            <td class="text-center"><?php echo e($drv->status_tersedia_driver); ?></td>
            <td class="text-center">
                <form action="<?php echo e(route('driver.destroy', $drv->id)); ?>" method="POST">
                    <a class="btn fa fa-eye" href="<?php echo e(route('driver.show',$drv->id)); ?>">Show</a>
                    <a class="btn fa fa-edit" href="<?php echo e(route('driver.edit',$drv->id)); ?>">Edit</a>
                    
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button type="submit" class="btn fa fa-trash-o" onclick="return confirm('Apakah Anda Yakin Ingin Menghapus Data Ini?'">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <tr>
            <td align="center" clospan="3">-</td>
        </tr>
    <?php endif; ?>    
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AJR_0450\resources\views/DriverCRUD/index.blade.php ENDPATH**/ ?>