package com.est.arester;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.est.arester.adapter.KatalogAdapter;
import com.est.arester.model.brosur.AsetKendaraan;
import com.est.arester.model.brosur.BrosurModel;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class ManagerActivity extends AppCompatActivity {
    TextView txtLanjutMobil, txtLogout, txtLanjutPendapatanTransaksi, txtTop5Driver, txtPerfomaDriver, txtTop5Customer;
    TextView btnLaporanPenyewaanMobilPerbulan, btnLaporanPendapatanTransaksiPerbulan, btnTop5Driver, btnPerformaDriver, btnTop5Customer;
    private KatalogAdapter katalogAdapter;
    private RecyclerView bRecyclerView;
    private RecyclerView.LayoutManager bLayoutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager);
        bRecyclerView = findViewById(R.id.rvBrosur);
        bLayoutManager = new GridLayoutManager(this, 2);
        bRecyclerView.setLayoutManager(bLayoutManager);
        btnLaporanPenyewaanMobilPerbulan = findViewById(R.id.btnLaporanPenyewaanMobilPerbulan);
        btnLaporanPendapatanTransaksiPerbulan = findViewById(R.id.btnLaporanPendapatanTransaksiPerbulan);
        btnTop5Driver = findViewById(R.id.btnTop5Driver);
        btnPerformaDriver = findViewById(R.id.btnPerformaDriver);
        btnTop5Customer = findViewById(R.id.btnTop5Customer);
        txtLogout = findViewById(R.id.txtLogout);
        txtLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManagerActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        btnTop5Customer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManagerActivity.this, ReportT5CTBActivity.class);
                startActivity(intent);
            }
        });
        btnPerformaDriver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManagerActivity.this, ReportPDBActivity.class);
                startActivity(intent);
            }
        });
        btnTop5Driver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManagerActivity.this, ReportT5DTBActivity.class);
                startActivity(intent);
            }
        });
        btnLaporanPendapatanTransaksiPerbulan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManagerActivity.this, ReportPTBActivity.class);
                startActivity(intent);
            }
        });
        btnLaporanPenyewaanMobilPerbulan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ManagerActivity.this, ReportPMBActivity.class);
                startActivity(intent);
            }
        });
        getBrosur();
    }

    private void getBrosur() {
        Interface anInterface = Network.getClient().create(Interface.class);
        Call<BrosurModel> brosurCall = anInterface.getbrosur("Tersedia");
        brosurCall.enqueue(new Callback<BrosurModel>() {
            @Override
            public void onResponse(Call<BrosurModel> call, Response<BrosurModel> response) {

                if(response.isSuccessful()){
                    List<AsetKendaraan> asetKendaraans = response.body().getAsetkendaraan();
                    katalogAdapter = new KatalogAdapter(asetKendaraans);
                    bRecyclerView.setAdapter(katalogAdapter);
                }else{
                    Toast.makeText(getApplicationContext(), "Gagal "+response.message().toString(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<BrosurModel> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Gagal", Toast.LENGTH_SHORT).show();
            }
        });
    }
}