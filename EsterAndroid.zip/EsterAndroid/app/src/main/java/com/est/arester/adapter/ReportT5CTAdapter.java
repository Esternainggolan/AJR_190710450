package com.est.arester.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.est.arester.R;
import com.est.arester.model.laporantop5customer.LaporanTop5Customer;

import java.util.List;

public class ReportT5CTAdapter extends RecyclerView.Adapter<ReportT5CTAdapter.MyViewHolder> {
    private List<LaporanTop5Customer> laporanTop5CustomerList;
    private Context context;

    public ReportT5CTAdapter(List<LaporanTop5Customer> laporanTop5DriverModelList) {
        this.laporanTop5CustomerList = laporanTop5DriverModelList;
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView txtNamaCustomer, txtIdCustomer, txtJumlahTransaksi;
        public MyViewHolder(View itemView) {
            super(itemView);
            txtNamaCustomer = (TextView) itemView.findViewById(R.id.txtNamaCustomer);
            txtIdCustomer = (TextView) itemView.findViewById(R.id.txtIdCustomer);
            txtJumlahTransaksi = (TextView) itemView.findViewById(R.id.txtJumlahTransaksi);

        }
    }

    @Override
    public ReportT5CTAdapter.MyViewHolder onCreateViewHolder (ViewGroup parent, int viewType){
        View mView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_laporan5, parent, false);
        ReportT5CTAdapter.MyViewHolder mViewHolder = new ReportT5CTAdapter.MyViewHolder(mView);
        return mViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ReportT5CTAdapter.MyViewHolder holder, int position) {
        final LaporanTop5Customer laporanTop5Customer = laporanTop5CustomerList.get(position);
        holder.txtNamaCustomer.setText(laporanTop5Customer.getNamaLengkap());
        holder.txtIdCustomer.setText(laporanTop5Customer.getIdCustomer());
        holder.txtJumlahTransaksi.setText(laporanTop5Customer.getJumlahTransaksi());
    }

    @Override
    public int getItemCount() {
        return laporanTop5CustomerList.size();
    }
}
