<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Transaksi extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();

    }
    // function tampilriwayatbyid_get() {
    //     $id_customer = $this->post('id_customer');
    //     $riwayattransaksi = $this->db->get('transaksi')->result();
    //     $this->response(array("riwayattransaksi"=>$riwayattransaksi, 200));
    // }
    function tampillaporanpendapatanbulan_get() {
        $n = "Peminjaman Mobil";
        $laporanbulanan = $this->db->query("SELECT c.nama_lengkap as nama_customer, d.nama_mobil as nama_mobil,  ifnull(t.id_driver,'".$n."') as jenis_trx, count(t.id_customer) as jumlah_transaksi, sum(t.total_biaya_sewa) as pendapatan from transaksi t join aset_kendaraan d on t.id_aset = d.id join customer c on t.id_customer = c.id group by nama_customer, jenis_trx")->result();
        $this->response(array("laporanpendapatanbulan"=>$laporanbulanan, 200));
    }
    function carilaporanpendapatanbulan_post() {
        $n = "Peminjaman Mobil";
        $bulan = $this->post('bulan');
        $laporanbulanan = $this->db->query("SELECT c.nama_lengkap as nama_customer, d.nama_mobil as nama_mobil,  ifnull(t.id_driver,'".$n."') as jenis_trx, count(t.id_customer) as jumlah_transaksi, sum(t.total_biaya_sewa) as pendapatan from transaksi t join aset_kendaraan d on t.id_aset = d.id join customer c on t.id_customer = c.id where month(t.tanggal_transaksi) in ('".$bulan."') group by nama_customer, jenis_trx")->result();
        $this->response(array("laporanpendapatanbulan"=>$laporanbulanan, 200));
    }


    
}

?>