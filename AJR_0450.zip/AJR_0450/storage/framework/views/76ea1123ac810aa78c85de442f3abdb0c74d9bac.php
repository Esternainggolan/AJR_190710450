
<?php $__env->startSection('content'); ?>

    <div class="container-fluid py-4" style="padding-left : 0%">
        <div class="row">
            <div class="col-10">
                <div class="card my-4">

                    <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                        <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                            <h6 class="text-black mx-3 text-center">
                                <strong> DATA MITRA UAJY RENTAL</strong> 
                            </h6>
                        </div>
                    </div>

                    <div>
                        <a class="fa fa-user-plus" href="<?php echo e(route('mitra.create')); ?>">Tambah Mitra</a>
                    </div>

                    <form action="<?php echo e(route('mitra.index')); ?>" method="GET">
                        <div class="mb-3 col-md-6 position-relative mt-n4 mx-3 z-index-2">
                            <div class="input-group input-group-outline">
                                <label class="form-label">Cari Data</label>
                                    <input type="search" class="form-control" name="search">
                            </div>
                        </div>
                    </form>

                    <div class="card-body px-0 pb-2">
                        <table class="table table-bordered">
                            <tr>
                                <th class="text-center">Id</th>
                                <th class="text-center">Nama Mitra</th>
                                <th class="text-center">Alamat</th>
                                <th class="text-center">Action</th>
                            </tr>
            
                    <?php if(count($mitra)): ?>
                    <?php $__currentLoopData = $mitra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                            <tr>
                                <td class="text-center"><?php echo e($mit->id); ?></td>
                                <td class="text-center"><?php echo e($mit->nama_mitra); ?></td>
                                <td class="text-center"><?php echo e($mit->alamat_mitra); ?></td>
                                <td class="text-center">
                                    <form action="<?php echo e(route('mitra.destroy', $mit->id)); ?>" method="POST">
                                        <a class="btn fa fa-eye" href="<?php echo e(route('mitra.show',$mit->id)); ?>"><i class="material-icons" style="font-size: 20px">Show</i></a>
                                        <a class="btn fa fa-edit" href="<?php echo e(route('mitra.edit',$mit->id)); ?>"><i class="material-icons" style="font-size: 20px">Edit</i></a>
                                        
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn fa fa-check" onclick="return confirm('Apakah Anda Yakin Ingin Menghapus Data Ini?'"><i class="material-icons" style="font-size: 20px">Delete</i></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr>
                                <td align="center" clospan="3">-</td>
                                
                            </tr>
                            
                            <?php endif; ?>    
                        </table>
                    </div>
                </div>                                           
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AJR_0450\resources\views/MitraCRUD/index.blade.php ENDPATH**/ ?>