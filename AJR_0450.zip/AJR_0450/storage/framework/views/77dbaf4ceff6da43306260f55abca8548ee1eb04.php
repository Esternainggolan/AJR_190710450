

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-center" >
    <div class="text-center">
        <h2>Show Data Pegawai</h2>
    </div>
</div>
<hr>
<div class="row no-gutters">
    <div class="col-6 col-md-4">
        <div class="d-flex justify-content-center">
            <img src="<?php echo e(asset('foto-pegawai/'.$pegawai->foto_pegawai)); ?>" class="img-fluid rounded my-md-0 mt-sm-0" alt="..." height="300" width="500">
        </div>
        <hr>
        <div>
            <a class="btn fa fa-close" href="<?php echo e(route('pegawai.index')); ?>"> Back</a>
        </div>
    </div>

    <div class="col-12 col-sm-6 col-md-8">
        <div class="col-md col-sm">
            <strong>
                <label class="mb-2">ID PEGAWAI</label>
            </strong>
            <p class="text-muted"><?php echo e($pegawai->id); ?></p>
        </div>
        <hr>
        <div class="col-md col-sm">
            <strong>
                <label class="mb-2">ID ROLE</label>
            </strong>
            <p class="text-muted"><?php echo e($pegawai->id_role); ?></p>
        </div>
        <hr>
        <div class="col-md col-sm">
            <strong>
                <label class="mb-2">NAMA PEGAWAI</label>
            </strong>
            <p class="text-muted"><?php echo e($pegawai->nama_pegawai); ?></p>
        </div>
        <hr>
        <div class="col-md col-sm">
            <strong>
                <label class="mb-2">TANGGAL LAHIR</label>
            </strong>
            <p class="text-muted"><?php echo e($pegawai->tgl_lahir_pegawai); ?></p>
        </div>
        <hr>
        <div class="col-md col-sm">
            <strong>
                <label class="mb-2">ALAMAT</label>
            </strong>
            <p class="text-muted"><?php echo e($pegawai->alamat_pegawai); ?></p>
        </div>
        <hr>
        <div class="col-md col-sm">
            <strong>
                <label class="mb-2">JENIS KELAMIN</label>
            </strong>
            <p class="text-muted"><?php echo e($pegawai->jenis_kelamin_pegawai); ?></p>
        </div>
        <hr>
        <div class="col-md col-sm">
            <strong>
                <label class="mb-2">EMAIL</label>
            </strong>
            <p class="text-muted"><?php echo e($pegawai->email_pegawai); ?></p>
        </div>
        <div>
            <a class="btn fa fa-close" href="<?php echo e(route('pegawai.index')); ?>"> Back</a>
        </div>
    </div>
</div>


       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AJR_0450\resources\views/PegawaiCRUD/show.blade.php ENDPATH**/ ?>