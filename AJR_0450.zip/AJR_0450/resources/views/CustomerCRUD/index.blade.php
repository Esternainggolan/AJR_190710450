@extends('dashboard.dashboard')

@section('content')
   
<div class="container-fluid py-4" style="padding-left : 0%">
        <div class="row">
            <div class="col-10">
                <div class="card my-4">

                    <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                        <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                            <h6 class="text-black mx-3 text-center">
                                <strong> DATA CUSTOMER UAJY RENTAL</strong> 
                            </h6>
                        </div>
                    </div>

                            <div>
                                <a class="fa fa-user-plus" href="{{ route('customer.create') }}"> Tambah Customer</a>
                            </div>

                            <form action="{{ route('customer.index') }}" method="GET">
                                <div class="mb-3 col-md-6 position-relative mt-n4 mx-3 z-index-2">
                                    <div class="input-group input-group-outline">
                                        <label class="form-label">Cari Disini</label>
                                            <input type="search" class="form-control" name="search">
                                    </div>
                                </div>
                            </form>

    <table class="table table-bordered">
        <tr>
            <th class="text-center">Id</th>
            <th class="text-center">Nama Customer</th>
            <th class="text-center">Action</th>
        </tr>

        @if(count($customer))
        @foreach($customer as $cust)

        <tr>
            <td class="text-center">{{ $cust->id }}</td>
            <td>{{ $cust->nama_lengkap }}</td>
            <td class="text-center">
                <form action="{{ route('customer.destroy', $cust->id) }}" method="POST">
                    <a class="btn fa fa-eye" href="{{ route('customer.show',$cust->id) }}">Show</a>
                    <a class="btn fa fa-edit" href="{{ route('customer.edit',$cust->id) }}">Edit</a>
                    
                    @csrf
                    @method('DELETE')

                    <button type="submit" class="btn fa fa-trash-o" onclick="return confirm('Apakah Anda Yakin Ingin Menghapus Data Ini?'">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
        @else
        <tr>
            <td align="center" clospan="3">-</td>
        </tr>
    @endif    
    </table>
@endsection