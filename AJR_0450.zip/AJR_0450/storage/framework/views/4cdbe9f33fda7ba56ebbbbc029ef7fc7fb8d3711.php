

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between mt-5 mb-5">
    <div>
        <h2>Edit Data Promo</h2>
    </div>

</div>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($errors); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<div class="container-fluid">
    
    <div class="card mb-3">
        <form action="<?php echo e(route('promo.update', $promo->id)); ?>" method="POST" enctype="multipart/form-data">
            <div class="row g-0">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="col-md-8">
                    <div class="card-body">
                        <div class="col-md col-sm">
                            <label class="mb-2">Kode Promo</label>
                            <input type="text" class="form-control mb-3" value="<?php echo e($promo->kode_promo); ?>" name="kode_promo">
                        </div>
    
                        <div class="col-md col-sm">
                            <label class="mb-2">Jenis Promo</label>
                            <input type="text" class="form-control mb-3" value="<?php echo e($promo->jenis_promo); ?>" name="jenis_promo">
                        </div>

                        <div class="col-md col-sm">
                            <label class="mb-2">Diskon</label>
                            <input type="text" class="form-control mb-3" value="<?php echo e($promo->diskon); ?>" name="diskon">
                        </div>

                        <div class="col-md col-sm">
                            <label class="mb-2">Keterangan</label>
                            <input type="text" class="form-control mb-3" value="<?php echo e($promo->keterangan); ?>" name="keterangan">
                        </div> 

                        <div class="col-md col-sm">
                            <label class="mb-2">Status Promo</label>
                            <input type="text" class="form-control mb-3" value="<?php echo e($promo->status_promo); ?>" name="status_promo">
                        </div>                                     
                    </div>
                </div>
                <div class="d-flex justify-content-center">
                    <button class="btn fa fa-check" type="submit">Ubah</button>
                    <button class="btn fa fa-close" type="reset">Batal</button>
                    <button class="btn btn-outline-danger mx-2" href="<?php echo e(route('promo.index')); ?>">Back</button>
                </div>
            </div>
        </form>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AJR_0450\resources\views/PromoCRUD/edit.blade.php ENDPATH**/ ?>