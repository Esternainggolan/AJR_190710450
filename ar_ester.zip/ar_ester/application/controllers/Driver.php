<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Driver extends REST_Controller {

    //1=sudah dikonfirmasi admin
    //2=masih belum dikonfirmasi
    //3=sudah tidak aktif


    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();
    }
    function tampildriver_post() {
        $id = $this->post('id');
        $driver = $this->db->query("SELECT * From driver where id = '".$id."' ")->result();
        $this->response(array("driver"=>$driver, 200));
    }
    
    function savedriver_post() {
        $id = $this->post('id');
        $nama = $this->post('nama');
        $alamat = $this->post('alamat');
        $notelp = $this->post('notelp');
        $email = $this->post('email');
        $status = $this->post('status');
        $driver = $this->db->query("UPDATE driver SET 
        nama_driver = '".$nama."' , 
        alamat_driver = '".$alamat."', 
        no_telp_driver = '".$notelp."', 
        email_driver = '".$email."', 
        status_tersedia_driver = '".$status."' 
        WHERE id = '".$id."'");
        $this->response(array("driver"=>$driver, 200));
    }
    function tampillaporantop5driver_get() {
        $laporantop5driver = $this->db->query("SELECT d.id as id_driver, d.nama_driver, count(t.id) as jumlah_transaksi from driver d join transaksi t on d.id = t.id_driver group by d.id order by jumlah_transaksi desc limit 5")->result();
        $this->response(array("laporantop5driver"=>$laporantop5driver, 200));
    }
    function carilaporantop5driver_post() {
        $bulan = $this->post('bulan');
        $laporantop5driver = $this->db->query("SELECT d.id as id_driver, d.nama_driver, count(t.id) as jumlah_transaksi from driver d join transaksi t on d.id = t.id_driver where month(t.tanggal_transaksi) in ('".$bulan."') group by d.id order by jumlah_transaksi desc limit 5")->result();
        $this->response(array("laporantop5driver"=>$laporantop5driver, 200));
    }

    function tampillaporanperfomadriver_get() {
        $laporantop5driver = $this->db->query("SELECT d.id as id_driver, d.nama_driver, count(t.id) as jumlah_transaksi, avg(t.rating_driver) as rerata_rating from driver d join transaksi t on d.id = t.id_driver group by d.id order by jumlah_transaksi desc")->result();
        $this->response(array("laporantop5driver"=>$laporantop5driver, 200));
    }
    function carilaporanperfomadriver_post() {
        $bulan = $this->post('bulan');
        $laporantop5driver = $this->db->query("SELECT d.id as id_driver, d.nama_driver, count(t.id) as jumlah_transaksi, avg(t.rating_driver) as rerata_rating from driver d join transaksi t on d.id = t.id_driver where month(t.tanggal_transaksi) in ('".$bulan."') group by d.id order by jumlah_transaksi desc")->result();
        $this->response(array("laporantop5driver"=>$laporantop5driver, 200));
    }

}

?>