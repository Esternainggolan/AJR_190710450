

<?php $__env->startSection('content'); ?>
   
<div class="d-flex justify-content-between mt-5 mb-5">
    <div>
        <h2>Aset Kendaraan CRUD</h2>
    </div>
    <div>
        <a class="btn btn-success" href="<?php echo e(route('kendaraan.create')); ?>">Tambah Data Kendaraan</a>
    </div>
</div>

    <table class="table table-bordered">
        <tr>
            <th class="text-center">Id</th>
            <th class="text-center">Nama Kendaraan</th>
            <th class="text-center">Status Kendaraan</th>
            <th class="text-center">Action</th>
        </tr>

        <?php if(count($aset_kendaraan)): ?>
        <?php $__currentLoopData = $aset_kendaraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td class="text-center"><?php echo e($mobil->id); ?></td>
            <td><?php echo e($mobil->nama_mobil); ?></td>
            <td><?php echo e($mobil->status_ketersediaan_mobil); ?></td>
            <td class="text-center">
                <form action="<?php echo e(route('kendaraan.destroy', $mobil->id)); ?>" method="POST">
                    <a class="btn btn-info btn-sm" href="<?php echo e(route('kendaraan.show',$mobil->id)); ?>">Show</a>
                    <a class="btn btn-primary btn-sm" href="<?php echo e(route('kendaraan.edit',$mobil->id)); ?>">Edit</a>
                    
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda Yakin Ingin Menghapus Data Ini?'">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <tr>
            <td align="center" clospan="3">Empty Data!!</td>
        </tr>
    <?php endif; ?>    
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xamp\htdocs\AJR_0450\resources\views/KendaraanCRUD/index.blade.php ENDPATH**/ ?>