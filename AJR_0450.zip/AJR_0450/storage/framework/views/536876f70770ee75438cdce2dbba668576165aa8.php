

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between mt-10 mb-10">
    <div class="text-center">
        <h2>Show Data Driver</h2>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div class="d-flex justify-content-center">
            <div class="card card-primary card-outline">
                <div class="card-body box-profile"> 
                    <hr>
                        <strong>
                            <i class="fa-solid fa-id-badge"></i>
                            Id Driver
                        </strong>
                        <p class="text-muted"><?php echo e($driver->id); ?></p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-id-badge"></i>
                            Nama Driver
                        </strong>
                        <p class="text-muted"><?php echo e($driver->nama_driver); ?></p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-id-badge"></i>
                            Tanggal Lahir
                        </strong>
                        <p class="text-muted"><?php echo e($driver->tgl_lahir_driver); ?></p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-id-badge"></i>
                            Jenis Kelamin
                        </strong>
                        <p class="text-muted"><?php echo e($driver->jenis_kelamin_driver); ?></p>
                        <hr>

                        <strong>
                            <i class="bi bi-arrow-up-left-circle-fill"></i>
                            Alamat Customer
                        </strong>
                        <p class="text-muted"><?php echo e($driver->alamat_driver); ?></p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-genderless"></i>
                            Nomor Telepon
                        </strong>
                        <p class="text-muted"><?php echo e($driver->no_telp_driver); ?></p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-genderless"></i>
                            Email
                        </strong>
                        <p class="text-muted"><?php echo e($driver->email_driver); ?></p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-genderless"></i>
                            Status
                        </strong>
                        <p class="text-muted"><?php echo e($driver->status_tersedia_driver); ?></p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-genderless"></i>
                            Bahasa
                        </strong>
                        <p class="text-muted"><?php echo e($driver->bahasa); ?></p>
                        <hr>

                        <strong>
                            <i class="fa-solid fa-genderless"></i>
                            File Pdf
                        </strong>
                        <p class="text-muted"><?php echo e($driver->file_pdf); ?></p>
                        <hr>
                       
                </div>
                <div class="text-center">
                            <a class="btn fa fa-close" href="<?php echo e(route('driver.index')); ?>">Back</a>
                        </div>  

            </div>

        </div>

    </div>

</div>
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AJR_0450\resources\views/DriverCRUD/show.blade.php ENDPATH**/ ?>