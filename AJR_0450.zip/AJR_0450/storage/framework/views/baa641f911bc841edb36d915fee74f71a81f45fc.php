

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between mt-5 mb-5">
    <div>
        <h2>Edit Data Driver</h2>
    </div>
    <div>
        <a class="btn btn-secondary" href="<?php echo e(route('driver.index')); ?>">Back</a>
    </div>
</div>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($errors); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<div class="container-fluid">
    
    <div class="card mb-3">
        <form action="<?php echo e(route('driver.update', $driver->id)); ?>" method="POST" enctype="multipart/form-data">
            <div class="row g-0">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="col-md-8">
                    <div class="card-body">
                        <div class="col-md col-sm">
                            <label class="mb-2">Nama Driver</label>
                            <input type="text" class="form-control mb-3" value="<?php echo e($driver->nama_driver); ?>" name="nama_driver">
                        </div>
    
                        <div class="col-md col-sm">
                            <label class="mb-2">Alamat</label>
                        <input type="text" class="form-control mb-3" value="<?php echo e($driver->alamat_driver); ?>" name="alamat_driver">
                        </div>

                        <div class="col-md col-sm">
                            <label class="mb-2">Tanggal Lahir</label>
                            <input type="date" class="form-control mb-3" value="<?php echo e($driver->tgl_lahir_driver); ?>" name="tgl_lahir_driver">
                        </div>

                        <div class="col-md col-sm">
                            <label class="mb-2">Jenis Kelamin</label>
                            <input type="text" class="form-control mb-3" value="<?php echo e($driver->jenis_kelamin_driver); ?>" name="jenis_kelamin_driver">
                        </div>

                        <div class="col-md col-sm">
                            <label class="mb-2">Nomor Telepon</label>
                            <input type="text" class="form-control mb-3" value="<?php echo e($driver->no_telp_driver); ?>" name="no_telp_driver">
                        </div> 

                        <div class="col-md col-sm">
                            <label class="mb-2">Email</label>
                            <input type="email" class="form-control mb-3" value="<?php echo e($driver->email_driver); ?>" name="email_driver">
                        </div>
                        
                        <div class="col-md col-sm">
                            <label class="mb-2">Password</label>
                        <input type="password" class="form-control mb-3" value="<?php echo e($driver->password_driver); ?>" name="password_driver">
                        </div>

                        <div class="col-md col-sm">
                            <label class="mb-2">Status Tersedia</label>
                        <input type="text" class="form-control mb-3" value="<?php echo e($driver->status_tersedia_driver); ?>" name="status_tersedia_driver">
                        </div>

                        <div class="col-md col-sm">
                            <label class="mb-2">Bahasa</label>
                        <input type="text" class="form-control mb-3" value="<?php echo e($driver->bahasa); ?>" name="bahasa">
                        </div>

                        <div class="col-md col-sm">
                            <label class="mb-2">File pdf</label>
                        <input type="file" class="form-control mb-3" value="<?php echo e($driver->file_pdf); ?>" name="file_pdf">
                        </div>
 
                    </div>
                </div>
                <div class="d-flex justify-content-center">
                    <button class="btn fa fa-check" type="submit">Ubah</button>
                    <div class="text-center">
                            <a class="btn fa fa-close" href="<?php echo e(route('driver.index')); ?>">Back</a>
                        </div> 
                </div>
            </div>
        </form>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\AJR_0450\resources\views/DriverCRUD/edit.blade.php ENDPATH**/ ?>