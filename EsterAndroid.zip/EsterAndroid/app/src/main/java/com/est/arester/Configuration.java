package com.est.arester;

public class Configuration {
    public static final String BASE_URL = "http://10.113.92.143:8080/atmarentalhk/";
    public static final String BASE_URL_IMAGE = "http://10.113.40.246:8080/atmarentalhk/";
}
